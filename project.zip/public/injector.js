document.getElementById('inject-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const targetURL = document.getElementById('target-url').value;

  const iframe = document.createElement('iframe');
  iframe.style = "position:fixed; top:0; left:0; width:100%; height:100%; border:none; z-index:999999;";
  iframe.src = targetURL;

  document.body.innerHTML = ''; // Clear current page content
  document.body.appendChild(iframe);

  const toolbar = document.createElement('div');
  toolbar.id = 'custom-toolbar';
  toolbar.innerHTML = `
    <div style="position:fixed; top:10px; right:10px; background:#303134; color:#fff; padding:10px; border-radius:8px;">
      <button onclick="window.location.reload()">Return</button>
      <button onclick="this.parentNode.style.display='none'">Hide Bar</button>
      <button onclick="toggleFullscreen()">Fullscreen</button>
    </div>
  `;
  document.body.appendChild(toolbar);

  window.toggleFullscreen = () => {
    if (!document.fullscreenElement) document.documentElement.requestFullscreen();
    else document.exitFullscreen();
  };
});