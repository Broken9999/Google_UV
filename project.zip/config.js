module.exports = {
  password: process.env.PASSWORD || "google",
  branding: {
    title: "Custom Unblocker",
    header: "Welcome to Your Custom Page Injector",
    logo: "/assets/logo.png",
  },
};