const express = require('express');
const session = require('express-session');
const dotenv = require('dotenv');
const path = require('path');
const config = require('./config');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: 'unblocker-secret-key',
  resave: false,
  saveUninitialized: true,
}));

app.get('/', (req, res) => {
  if (!req.session.authenticated) {
    return res.render('password', { branding: config.branding });
  }
  res.render('unblocker', { branding: config.branding });
});

app.post('/password', (req, res) => {
  if (req.body.password === config.password) {
    req.session.authenticated = true;
    return res.redirect('/');
  }
  res.send(`<h2>Incorrect Password</h2><a href="/">Try Again</a>`);
});

app.get('/injector', (req, res) => {
  res.render('injector', { branding: config.branding });
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
